/*Write a loop to print the powers of 3 under 10,000 (it should print 3, 9, 27, etc.). Rewrite this loop with a while loop. (Hint: Provide the setup before the loop.*/

var x = 3;
while (x < 10000) {
console.log(x);
 x=x*3;
}
console.log("The numbers above are all of the powers of 3 under 10000");
