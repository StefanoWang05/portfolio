#3 If I leave my house at 6:52 am and run 1 mile at an easy pace (8:15 per mile), then 3 miles at
#  tempo (7:12 per mile) and 1 mile at easy pace again, what time do I get home for breakfast
second=1
minute= second*60
hour= minute*60
day=hour*24

def basic(name):
    print("hello " + name + " nice to meet you")


name = input("What is your name")

basic(name)
