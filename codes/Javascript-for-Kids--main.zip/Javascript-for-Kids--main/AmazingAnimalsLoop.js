/* This is a loop that modifies an array of animals and makes them Awesome. This loop adds the adjective Awesome to every single animal listed and it doesn't stop if it hasn't*/

var animals = ["Cat", "Fish","Lemur", "Komodo Dragon"];
for (var i = 0; i < animals.length; i++) {
 console.log("Awesome " + animals[i] + ".");
}
